<?php
/*********************************************************************************
 * "Powered by BizForce"
 * BFtool new_Fields_types 1.0 2021-01-28
 *  
 ********************************************************************************/

/**
 * THIS CLASS IS FOR DEVELOPERS TO MAKE CUSTOMIZATIONS IN
 */
require_once('modules/BF_Dynamicbases/BF_Dynamicbases_sugar.php');
class BF_Dynamicbases extends BF_Dynamicbases_sugar {
    public function __construct() {
        parent::__construct();
    }
}
?>