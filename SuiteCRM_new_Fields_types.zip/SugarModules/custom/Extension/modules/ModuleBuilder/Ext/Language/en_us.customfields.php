<?php
if (!defined('sugarEntry') || !sugarEntry) {die('Not A Valid Entry Point');}
/*********************************************************************************
 * "Powered by BizForce"
 * BFtool new_Fields_types 1.0 2021-01-28
 *  
 ********************************************************************************/
$mod_strings['fieldTypes']['dynamicbase'] = 'Dynamicbase';
$mod_strings['fieldTypes']['collection'] = 'Collection';
$mod_strings['fieldTypes']['collection_files'] = 'Collection Files';
$mod_strings['LBL_POPHELP_COLLECTION_LINK'] = 'The module (via link) will use for for save data';