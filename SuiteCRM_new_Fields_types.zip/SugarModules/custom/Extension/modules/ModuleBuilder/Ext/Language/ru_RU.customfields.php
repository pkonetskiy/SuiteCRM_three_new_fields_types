<?php
if (!defined('sugarEntry') || !sugarEntry) {die('Not A Valid Entry Point');}
/*********************************************************************************
 * "Powered by BizForce"
 * BFtool new_Fields_types 1.0 2021-01-28
 *  
 ********************************************************************************/
$mod_strings['fieldTypes']['dynamicbase'] = 'Расширяемое базовое поле';
$mod_strings['fieldTypes']['collection'] = 'Коллекция полей';
$mod_strings['fieldTypes']['collection_files'] = 'Коллекция файлов';
$mod_strings['LBL_POPHELP_COLLECTION_LINK'] = 'Этот модуль (через связь) будет использоваться для хранения данных';