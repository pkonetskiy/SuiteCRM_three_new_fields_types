<?php
if (!defined('sugarEntry') || !sugarEntry) {die('Not A Valid Entry Point');}
/*********************************************************************************
 * "Powered by BizForce"
 * BFtool new_Fields_types 1.0 2021-01-28
 *  
 ********************************************************************************/
$mod_strings['LBL_NOT_SUPPORT'] = 'Этот тип поле не поддерживается в Package для MobuleBuilder, только в Studio';
$mod_strings['LBL_SELECT_MODULE'] = 'Выберите модуль';
$mod_strings['LBL_SET_LINK'] = 'Имя связи';
$mod_strings['LBL_FIELD_OF_MODULE'] = 'Имя поля для модуля';
$mod_strings['LBL_FIELD_OF_SIZE'] = 'Размер поля <br>(всего ';