<?php
if (!defined('sugarEntry') || !sugarEntry) {die('Not A Valid Entry Point');}
/*********************************************************************************
 * "Powered by BizForce"
 * BFtool new_Fields_types 1.0 2021-01-28
 *  
 ********************************************************************************/
$mod_strings['LBL_NOT_SUPPORT'] = 'The field type do not support in Package of MobuleBuilder only in Studio';
$mod_strings['LBL_SELECT_MODULE'] = 'Select module';
$mod_strings['LBL_SET_LINK'] = 'Name of <br> relationship';
$mod_strings['LBL_FIELD_OF_MODULE'] = 'Field of module';
$mod_strings['LBL_FIELD_OF_SIZE'] = 'Field size <br>(must be total ';