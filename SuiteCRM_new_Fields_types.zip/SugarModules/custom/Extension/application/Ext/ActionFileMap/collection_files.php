<?php
if (!defined('sugarEntry') || !sugarEntry) {die('Not A Valid Entry Point');}
/*********************************************************************************
 * "Powered by BizForce"
 * BFtool new_Fields_types 1.0 2021-01-28
 *  
 ********************************************************************************/
$action_file_map['viewsugarfieldcollectionfiles'] = 'custom/include/SugarFields/Fields/Collection_files/view.sugarfieldcollection_files.php';