<?php
if (!defined('sugarEntry') || !sugarEntry) {die('Not A Valid Entry Point');}
/*********************************************************************************
 * "Powered by BizForce"
 * BFtool new_Fields_types 1.0 2021-01-28
 *  
 ********************************************************************************/

$app_list_strings['moduleList']['BF_Dynamicbases'] = 'Dynamicbases';
$app_list_strings['moduleList']['BF_Multi_Files'] = 'Multi Files';
$app_list_strings['fieldType_collection_files']['LBL_DROP'] = 'Drop the files here';
$app_list_strings['fieldType_collection_files']['LBL_FILE_SIZE'] = 'File name (file size)';