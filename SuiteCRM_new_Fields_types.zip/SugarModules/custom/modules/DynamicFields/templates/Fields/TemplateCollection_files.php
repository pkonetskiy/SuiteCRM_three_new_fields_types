<?php
if (!defined('sugarEntry') || !sugarEntry) {die('Not A Valid Entry Point');}
/*********************************************************************************
 * "Powered by BizForce"
 * BFtool new_Fields_types 1.0 2021-01-28
 *  
 ********************************************************************************/

require_once('custom/modules/DynamicFields/templates/Fields/TemplateCollection.php');
#[\AllowDynamicProperties]
class CustomTemplateCollection_files extends CustomTemplateCollection
{
    public $type='collection_files';
}
